export const hasSites = () => OMAPI.site_ids && OMAPI.site_ids.length > 0;
