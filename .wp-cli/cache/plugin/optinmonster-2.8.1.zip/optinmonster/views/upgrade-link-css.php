<style type="text/css">
	.om-submenu-highlight {
		background-color: #1da867;
	}

	.om-menu-highlight {
		color: #fff;
	}

	.om-plugin-upgrade-link,
	.om-plugin-upgrade-link:hover {
		color: #1da867;
		font-weight: 600;
	}
</style>
